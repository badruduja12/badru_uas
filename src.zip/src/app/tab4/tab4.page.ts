import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import axios from 'axios';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page{

  public  MahasiswaDataBaru:any = [];

  public nama_lengkap:any="";
  public jenis_kelamin:any="";
  public no_handphone:any="";
  public email:any="";
  public asal_sekolah:any="";
  public jurusan:any="";
  public jenjang:any="";
  public kelas:any="";
  public info:any="";

  constructor(
    public modalCtrl: ModalController, private router:Router
  ) {
    this.getData();
    
  }
  Getdota(){
    this.router.navigate(['/fee'])
  }
  // ngOnInit() {
  // }
  async getData() {
    try {
      const res = await axios.post('https://praktikum-cpanel-unbin.com/api_badru/uas_badru/get_data.php');
      this.MahasiswaDataBaru = res.data.result;
      console.log(this.MahasiswaDataBaru);
  
      }catch(err){
        console.log(err);
      }
    }


    

}
