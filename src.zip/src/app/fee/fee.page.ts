import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';


import axios from 'axios';

@Component({
  selector: 'app-fee',
  templateUrl: './fee.page.html',
  styleUrls: ['./fee.page.scss'],
})
export class FeePage  {
  
  public  feeData:any = [];

  public nama_lengkap:any="";
  public status:any="";
  public jumlah_fee:any="";
  

  constructor(public modalCtrl: ModalController,  private router:Router) 
  { this.getData(); }
  handleRefresh(event:any) {
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }
  Getdota(){
    this.router.navigate(['/fee'])
  }
  back(){
    this.router.navigate(['/tabs/tab2'])
  }
  

  async getData() {
    try {
      const res = await axios.post('https://praktikum-cpanel-unbin.com/api_badru/uas_badru/fee.php');
      this.feeData = res.data.result;
      console.log(this.feeData);
  
      }catch(err){
        console.log(err);
      }
    }

}
